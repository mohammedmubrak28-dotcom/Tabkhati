@file:OptIn(ExperimentalMaterial3Api::class)

package com.tabakhati.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val Cream = Color(0xFFFBF6EE)
private val Brown = Color(0xFF3B2F27)
private val Sage = Color(0xFF5F7F63)
private val CardBg = Color(0xFFFFFDF9)

private val Palette = lightColorScheme(
    primary = Sage,
    onPrimary = Color.White,
    background = Cream,
    onBackground = Brown,
    surface = Cream,
    onSurface = Brown,
    surfaceVariant = Color(0xFFEDE6D8),
    onSurfaceVariant = Color(0xFF6B5B4D),
    outline = Color(0xFFB8AA98)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // اتجاه من اليمين لليسار دائمًا، بغض النظر عن لغة الجهاز
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = Palette) { App() }
            }
        }
    }
}

@Composable
private fun App() {
    val dao = AppDb.get(LocalContext.current).dao()
    var screen by rememberSaveable { mutableStateOf("home") }
    var editId by rememberSaveable { mutableStateOf(0L) }
    var tab by rememberSaveable { mutableStateOf(0) }

    when (screen) {
        "recipe" -> RecipeForm(dao, editId) { screen = "home" }
        "note" -> NoteForm(dao, editId) { screen = "home" }
        else -> Home(
            dao = dao,
            tab = tab,
            onTab = { tab = it },
            onRecipe = { editId = it; screen = "recipe" },
            onNote = { editId = it; screen = "note" }
        )
    }
}

// ---------------------------------------------------------------- الرئيسية

@Composable
private fun Home(
    dao: AppDao,
    tab: Int,
    onTab: (Int) -> Unit,
    onRecipe: (Long) -> Unit,
    onNote: (Long) -> Unit
) {
    val recipes by remember { dao.recipes() }.collectAsState(initial = emptyList())
    val notes by remember { dao.notes() }.collectAsState(initial = emptyList())

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                CenterAlignedTopAppBar(title = { Text("طبخاتي") })
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { onTab(0) }, text = { Text("الوصفات") })
                    Tab(selected = tab == 1, onClick = { onTab(1) }, text = { Text("الملاحظات") })
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { if (tab == 0) onRecipe(0L) else onNote(0L) },
                containerColor = Sage,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة")
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) {
                if (recipes.isEmpty()) {
                    EmptyHint("لا توجد وصفات بعد.\nاضغط + لإضافة أول وصفة")
                } else {
                    CardList(
                        items = recipes.map { Triple(it.id, it.name, it.ingredients.ifBlank { it.method }) },
                        onClick = onRecipe
                    )
                }
            } else {
                if (notes.isEmpty()) {
                    EmptyHint("لا توجد ملاحظات بعد.\nاضغط + لكتابة ملاحظة")
                } else {
                    CardList(
                        items = notes.map { Triple(it.id, it.title, it.content) },
                        onClick = onNote
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyHint(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun CardList(items: List<Triple<Long, String, String>>, onClick: (Long) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items, key = { it.first }) { (id, title, subtitle) ->
            Card(
                onClick = { onClick(id) },
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (subtitle.isNotBlank()) {
                        Text(
                            subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- النماذج

@Composable
private fun FormScreen(
    title: String,
    canSave: Boolean,
    existing: Boolean,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onDelete: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    var confirm by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("حذف") },
            text = { Text("هل تريد الحذف نهائيًا؟") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    if (existing) {
                        IconButton(onClick = { confirm = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف")
                        }
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = onSave,
                enabled = canSave,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) { Text("حفظ") }
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    minLines: Int = 1,
    singleLine: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        minLines = minLines,
        singleLine = singleLine,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun RecipeForm(dao: AppDao, id: Long, close: () -> Unit) {
    val scope = rememberCoroutineScope()
    var loaded by rememberSaveable { mutableStateOf(id == 0L) }
    var name by rememberSaveable { mutableStateOf("") }
    var quantities by rememberSaveable { mutableStateOf("") }
    var ingredients by rememberSaveable { mutableStateOf("") }
    var method by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(id) {
        if (!loaded) {
            dao.recipe(id)?.let {
                name = it.name
                quantities = it.quantities
                ingredients = it.ingredients
                method = it.method
                notes = it.notes
            }
            loaded = true
        }
    }

    FormScreen(
        title = if (id == 0L) "وصفة جديدة" else "تعديل الوصفة",
        canSave = loaded && name.isNotBlank(),
        existing = id != 0L,
        onBack = close,
        onSave = {
            scope.launch {
                dao.saveRecipe(
                    Recipe(
                        id = id,
                        name = name.trim(),
                        quantities = quantities.trim(),
                        ingredients = ingredients.trim(),
                        method = method.trim(),
                        notes = notes.trim()
                    )
                )
                close()
            }
        },
        onDelete = { scope.launch { dao.deleteRecipe(id); close() } }
    ) {
        Field(name, { name = it }, "اسم الوصفة", singleLine = true)
        Field(quantities, { quantities = it }, "المقادير", minLines = 3)
        Field(ingredients, { ingredients = it }, "المكونات", minLines = 4)
        Field(method, { method = it }, "طريقة التحضير", minLines = 5)
        Field(notes, { notes = it }, "ملاحظات (اختياري)", minLines = 2)
    }
}

@Composable
private fun NoteForm(dao: AppDao, id: Long, close: () -> Unit) {
    val scope = rememberCoroutineScope()
    var loaded by rememberSaveable { mutableStateOf(id == 0L) }
    var title by rememberSaveable { mutableStateOf("") }
    var content by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(id) {
        if (!loaded) {
            dao.note(id)?.let {
                title = it.title
                content = it.content
            }
            loaded = true
        }
    }

    FormScreen(
        title = if (id == 0L) "ملاحظة جديدة" else "تعديل الملاحظة",
        canSave = loaded && title.isNotBlank(),
        existing = id != 0L,
        onBack = close,
        onSave = {
            scope.launch {
                dao.saveNote(Note(id = id, title = title.trim(), content = content.trim()))
                close()
            }
        },
        onDelete = { scope.launch { dao.deleteNote(id); close() } }
    ) {
        Field(title, { title = it }, "العنوان", singleLine = true)
        Field(content, { content = it }, "المحتوى", minLines = 10)
    }
}
