# طبخاتي

تطبيق Android أصلي (Kotlin + Jetpack Compose + Room) لحفظ الوصفات والملاحظات محليًا.

## بناء APK

**الطريقة الأسهل (Android Studio):** افتح مجلد المشروع، ثم `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

**من سطر الأوامر** (يلزم JDK 17 و Android SDK، ومتغير `ANDROID_HOME`):

```
./gradlew assembleDebug      # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease    # app/build/outputs/apk/release/app-release.apk (أصغر حجمًا)
```

انقل الملف إلى الهاتف وثبّته (فعّل «التثبيت من مصادر غير معروفة» إن طُلب).
